const Discord = require("discord.js")
const Event = require("../../Structure/Event")

module.exports = new Event("voiceStateUpdate", async (bot, oldState, newState) => {
 /*let newUserChannel = newState.channel;
       let oldUserChannel = oldState.channel;
    console.log(newUserChannel)
       if(newUserChannel === "988501565247750225")
       { 
           console.log("Joined vc with id "+newUserChannel);
       }
       else{
        
           console.log("Left vc");
       }*/
})

